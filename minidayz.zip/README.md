# Browser Mini DayZ

Progress saving doesn't work.

# [Play in Browser](https://meterpreter57.github.io/minidayz_1.4.1/)


## Plans for the future:
1. [ ] Restore c2runtime.js and data.js to original source code
2. [ ] Add mods support without changing original files
	- [ ] Mod selection from list
3. [ ] Add server response simulator as mod
4. [ ] Add working in-game map mod (work in progress)
