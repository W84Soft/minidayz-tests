import "./server/singleplayer.js";
import "./server/multiplayer.js";
import "./server/app.js"