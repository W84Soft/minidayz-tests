import { Router } from "express";

export const router={
	sp:Router(),
	mp:Router(),
	api:Router(),
}